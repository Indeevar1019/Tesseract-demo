package com.example.Tesseractdemo.rest;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.servlet.view.RedirectView;

import ch.qos.logback.core.model.Model;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

@RestController
@SecurityRequirement(name = "bearerAuth")
public class DemoController{
	    
	    @RequestMapping(value = "/upload", method = RequestMethod.POST,consumes = { MediaType.MULTIPART_FORM_DATA_VALUE })
	    @PostMapping("/upload")
	    public ResponseEntity<String> singleFileUpload(@RequestPart MultipartFile file) throws IOException, TesseractException {


	        File convFile = convert(file);
	        Tesseract tesseract = new Tesseract();
	        tesseract.setDatapath("F:\\TesseractENG\\tessdata");
	        String text = tesseract.doOCR(convFile);
	        System.out.print(text);
	        //return ResponseEntity.ok().build();
	        return new ResponseEntity<>(text, HttpStatus.OK);
	    }
	    public static File convert(MultipartFile file) throws IOException {
	        File convFile = new File(file.getOriginalFilename());
	        convFile.createNewFile();
	        FileOutputStream fos = new FileOutputStream(convFile);
	        fos.write(file.getBytes());
	        fos.close();
	        return convFile;
	    }
}


//package com.example.Tesseractdemo.rest;
//import org.springframework.web.bind.annotation.RestController;
//
//import java.awt.image.BufferedImage;
//import java.io.BufferedWriter;
//import java.io.File;
//import java.io.FileWriter;
//import java.io.IOException;
//
//import javax.imageio.ImageIO;
//
//import org.springframework.web.bind.annotation.GetMapping;
//
//import net.sourceforge.tess4j.ITesseract;
//import net.sourceforge.tess4j.Tesseract; 
//import net.sourceforge.tess4j.TesseractException; 
//@RestController
//public class DemoController {
//	@GetMapping("/")
//	public String say() {
//	ITesseract tesseract = new Tesseract(); 
//
//    try { 
//
//       // the path of your tess data folder inside the extracted file
//       tesseract.setDatapath("F:\\TesseractENG\\tessdata"); 
//       tesseract.setLanguage("eng");
//       //tesseract.setPageSegMode(1);
//       //tesseract.setOcrEngineMode(1);
//       File imageFile = new File("E:\\tess4j\\Tess4J\\test\\resources\\test-data\\aa.jpg");
//       
//       BufferedImage bufferedImage = ImageIO.read(imageFile);
//       // path of your image file 
//       String text = tesseract.doOCR(new File("E:\\tess4j\\Tess4J\\test\\resources\\test-data\\aa.jpg"));         
//       System.out.print(text);
//       // Create a FileWriter with the specified file path
//       FileWriter fileWriter = new FileWriter("E:\\tess4j\\Tess4J\\test\\result\\output.txt.txt");
//
//       // Wrap FileWriter in BufferedWriter for efficient writing
//       BufferedWriter bufferedWriter = new BufferedWriter(fileWriter);
//
//       // Write the text to the file
//       bufferedWriter.write(text);
//
//       // Close the BufferedWriter to flush and release resources
//       bufferedWriter.close();
//       System.out.println("Text has been written to the file successfully.");
//       return text;
//
//    } catch (TesseractException | IOException e) { 
//         e.printStackTrace(); 
//    }
//    return "None";
//	}
//
//
//}
