package com.example.Tesseractdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
//import org.junit.runner.RunWith;
//import org.mockito.Mock;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.boot.test.context.SpringBootTest;
//import org.springframework.test.context.junit4.SpringRunner;
//
//import com.example.Tesseractdemo.model.User;
//import com.example.Tesseractdemo.repository.UserRepository;
//import com.example.Tesseractdemo.service.AuthenticationService;

//@RunWith(SpringRunner.class)
@SpringBootTest
class TesseractdemoApplicationTests {
	
//	@Autowired
//	private AuthenticationService service;
//	
//	@Mock
//	private UserRepository repository;
//	
//	@Mock
//	private User request;
//	
//	public void authenticateTest() {
//		when
//	}
	@Test
	void contextLoads() {
	}

}
