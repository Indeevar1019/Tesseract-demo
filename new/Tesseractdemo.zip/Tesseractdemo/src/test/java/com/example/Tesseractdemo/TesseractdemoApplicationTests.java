package com.example.Tesseractdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TesseractdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
