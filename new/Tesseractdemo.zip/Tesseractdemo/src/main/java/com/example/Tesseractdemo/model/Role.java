package com.example.Tesseractdemo.model;

public enum Role {
	USER,
	ADMIN

}
